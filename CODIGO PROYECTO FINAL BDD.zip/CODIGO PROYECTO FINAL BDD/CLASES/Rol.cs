﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace APPARMSA.Clases
{
    public class Rol
    {
        public int IdRol;
        public string Descripcion;
        public DataTable Permisos;

        public Rol(int idRol, string descripcion, DataTable permisos)
        {
            IdRol = idRol;
            Descripcion = descripcion;
            Permisos = permisos;
        }

        public Rol() {

        }

        public Rol(Conexion con, int idRol) {
            DataTable dtRol = new DataTable();

            dtRol = con.EjecutarConsulta("SELECT * FROM ROL WHERE ID_ROL=" + idRol);

            IdRol = (int)dtRol.Rows[0]["ID_ROL"];
            Descripcion = dtRol.Rows[0]["Descripcion"].ToString();
            Permisos = con.EjecutarConsulta("SELECT PXR.ID_PERMISO,P.DESCRIPCION,PXR.HABILITADO FROM PERMISO_X_ROL PXR, PERMISO P WHERE PXR.ID_PERMISO = P.ID_PERMISO AND PXR.ID_ROL="+ IdRol.ToString());
        }

    }
}