﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace APPARMSA.Clases
{
    public class Usuario
    {
        public int Id_Usuario;
        public string Username;
        public string Password;
        public string Nombres;
        public string Apellidos;
        public string Identificacion;
        public string Genero;
        public DateTime Fecha_Nacimiento;
        public int Id_Agencia;
        public String Nombre_Agencia;
        public int Id_Rol;
        public string Rol_Descripcion;
        public DataTable Permisos;

        public Usuario(int id_Usuario, string username, string password, string nombres, string apellidos, string identificacion, string genero, DateTime fecha_Nacimiento, int id_Agencia, string nombre_Agencia, int id_Rol, string rol_Descripcion)
        {
            Id_Usuario = id_Usuario;
            Username = username;
            Password = password;
            Nombres = nombres;
            Apellidos = apellidos;
            Identificacion = identificacion;
            Genero = genero;
            Fecha_Nacimiento = fecha_Nacimiento;
            Id_Agencia = id_Agencia;
            Nombre_Agencia = nombre_Agencia;
            Id_Rol = id_Rol;
            Rol_Descripcion = rol_Descripcion;
        }
        public Usuario() { }

        public Usuario(Conexion con, int idUsuario)
        {
            DataTable dtUsuario = new DataTable();

            dtUsuario = con.EjecutarConsulta("SELECT USUARIO.*, SEDE.NOMBRE as NOMBRE_SEDE, ROL.DESCRIPCION AS NOMBRE_ROL FROM USUARIO, SEDE, ROL WHERE USUARIO.ID_SEDE = SEDE.ID_SEDE AND USUARIO.Id_Rol=ROL.Id_Rol AND USUARIO.Id_Usuario=" + idUsuario);

            Id_Usuario = (int)dtUsuario.Rows[0]["Id_Usuario"];
            Username = dtUsuario.Rows[0]["username"].ToString();
            Password = dtUsuario.Rows[0]["password"].ToString();
            Nombres = dtUsuario.Rows[0]["Nombres"].ToString();
            Apellidos = dtUsuario.Rows[0]["Apellidos"].ToString();
            Identificacion = dtUsuario.Rows[0]["Identificacion"].ToString();
            Genero = dtUsuario.Rows[0]["Genero"].ToString();
            Fecha_Nacimiento = DateTime.Parse(dtUsuario.Rows[0]["Fecha_Nacimiento"].ToString());
            Id_Agencia = (int)dtUsuario.Rows[0]["Id_SEDE"];
            Nombre_Agencia = dtUsuario.Rows[0]["NOMBRE_SEDE"].ToString();
            Id_Rol = (int)dtUsuario.Rows[0]["Id_Rol"];
            Rol_Descripcion = dtUsuario.Rows[0]["NOMBRE_ROL"].ToString();

            Permisos = con.EjecutarConsulta("SELECT USUARIO.USERNAME,PXR.ID_PERMISO, PXR.HABILITADO, PER.DESCRIPCION AS PERMISO FROM USUARIO,ROL,PERMISO_X_ROL PXR, PERMISO PER WHERE USUARIO.ID_ROL=ROL.ID_ROL AND PXR.Id_Rol=ROL.Id_Rol AND PXR.Id_Permiso=PER.Id_Permiso AND USUARIO.ID_USUARIO=" + Id_Usuario.ToString());

        }
    }
}