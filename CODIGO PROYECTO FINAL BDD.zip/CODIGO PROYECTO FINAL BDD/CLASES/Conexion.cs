﻿using APPARMSA.Clases;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data.OracleClient;

namespace APPARMSA
{



    public class Conexion
    {
        private SqlConnection con = new SqlConnection("Server=DESKTOP-8PLF40V\\SQLEXPRESS;Database=ProyectoFinalBDD;User Id=sa;Password = Poporopo123;");


        public DataTable EjecutarConsulta(string strConsulta)
        {
            DataTable dt = new DataTable();
            con.Open();
            SqlCommand cmd = new SqlCommand(strConsulta, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            da.Dispose();
            return dt;
        }

        public bool EjecutarComando(string strComandoSQL)
        {
            try
            {
                strComandoSQL = strComandoSQL.ToUpper();
                con.Open();
                SqlCommand cmd = new SqlCommand(strComandoSQL, con);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        public bool EjecutarComandoSinMayusc(string strComandoSQL)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(strComandoSQL, con);
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        public void RegistrarBitacora(Usuario usuarioBit, string strAccion, string strDescripcion)
        {
            try
            {
                EjecutarComando("insert into bitacora(Id_Usuario, Fecha_Hora, Descripcion, Tipo_Accion) values(" + usuarioBit.Id_Usuario.ToString() + ", GETDATE(), '" + strDescripcion + "', '" + strAccion + "')");
            }
            catch (Exception) { }
        }

    }


}