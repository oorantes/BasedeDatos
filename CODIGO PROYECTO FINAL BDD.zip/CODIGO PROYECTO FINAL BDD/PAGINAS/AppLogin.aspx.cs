﻿using APPARMSA.Clases;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace APPARMSA
{
    public partial class AppLogin : System.Web.UI.Page
    {
        Conexion con = new Conexion();
        protected void Page_Load(object sender, EventArgs e)
        {
            OcultarPanelesAlerta();

        }

        protected void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text.Length > 0 && txtPassword.Text.Length > 0)
            {
                /*Session["USUARIO"] = new Usuario(con, 1);
                Response.Redirect("Inicio.aspx");*/

                DataTable dtLogin = con.EjecutarConsulta("SELECT * FROM USUARIO WHERE USERNAME='" + txtUsuario.Text + "'");
                if (dtLogin.Rows.Count > 0) {
                    if (dtLogin.Rows[0]["PASSWORD"].ToString().Equals(""))
                    {
                        con.EjecutarComandoSinMayusc("UPDATE USUARIO SET PASSWORD=HASHBYTES('MD5',CONVERT(NVARCHAR(4000),'" + txtPassword.Text + "')) WHERE USERNAME='" + txtUsuario.Text + "'");
                        Session["USUARIO"] = new Usuario(con, int.Parse(dtLogin.Rows[0]["ID_USUARIO"].ToString()));
                        Response.Redirect("Inicio.aspx");
                    }
                    else {
                        dtLogin = con.EjecutarConsulta("SELECT * FROM USUARIO WHERE USERNAME='" + txtUsuario.Text + "' AND PASSWORD=HASHBYTES('MD5',CONVERT(NVARCHAR(4000),'" + txtPassword.Text + "'))");
                        if (dtLogin.Rows.Count > 0) {
                            Session["USUARIO"]= new Usuario(con, int.Parse(dtLogin.Rows[0]["ID_USUARIO"].ToString()));
                            Response.Redirect("Inicio.aspx");
                        } else {
                            Alerta("Contraseña incorrecta.", 1);
                        }
                    }

                    
;                } else {
                    Alerta("Usuario no existe.", 1);
                }

            }
            else {
                Alerta("Usuario y contraseña incorrectos.", 1);
            }

            
        }

        private void OcultarPanelesAlerta() {
            pnlAlertaLogin.Visible = false;
        }

        private void Alerta(string textoAlerta, int tipoAlerta)
        {
            if (tipoAlerta == 1)
            {
                //danger
                pnlAlertaLogin.CssClass = "col-md-12 alert alert-danger";
            }
            else
            {

                if (tipoAlerta == 2)
                {
                    //info
                    pnlAlertaLogin.CssClass = "col-md-12 alert alert-info";
                }
                else
                {
                    //success
                    pnlAlertaLogin.CssClass = "col-md-12 alert alert-success";
                }
            }
            lblAlertaLogin.Text = textoAlerta;
            pnlAlertaLogin.Visible = true;
        }
    }
}