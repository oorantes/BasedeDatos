﻿using APPARMSA.Clases;
using GemBox.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace APPARMSA
{
    public partial class Inicio : Page
    {
        Conexion con = new Conexion();
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }


        protected void btnIViajes_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Viajes.aspx");
        }

        protected void btnICatalogos_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Catalogos.aspx");
        }

        protected void btnIVentas_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Ventas.aspx");
        }
    }
    }