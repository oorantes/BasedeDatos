﻿using APPARMSA.Clases;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace APPARMSA
{
    public partial class AdminUsuarios : Page
    {
        Conexion con = new Conexion();
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidacionPermisosRol();
            Busqueda();
            OcultarPanelesAlerta();
            if (!this.IsPostBack) {
                CambiarModoPnlDetalle(true);
                LlenadoInicial();
            }
        }

        private void ValidacionPermisosRol() {
            //Valida si hay inicio de sesion
            if (Session["USUARIO"] != null)
            {
                try
                {
                    Usuario loggedUser = (Usuario)Session["USUARIO"];
                    foreach (DataRow dr in loggedUser.Permisos.Rows)
                    {
                        //PERMISOS A LA PAGINA COMO TAL
                        if (int.Parse(dr["ID_PERMISO"].ToString()) == 3)
                        {
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                //Si tiene permisos para esta pagina

                            }
                            else
                            {
                                Response.Redirect("Inicio.aspx");
                            }
                        }
                        else { }
                    }
                }
                catch (Exception)
                {
                    //Ya que dio un error se cierra la sesión
                    Session["USUARIO"] = null;
                    Response.Redirect("AppLogin.aspx");
                }
            }
            else
            {
                Response.Redirect("AppLogin.aspx");
            }
        }

        private void OcultarPanelesAlerta() {
            pnlAlerta.Visible = false;
            pnlAlertaNoResultados.Visible = false;
            pnlConfElim.Visible = false;
        }
        
        private void LlenarGrid(String strConsulta) {
            grdUsuarios.DataSource = con.EjecutarConsulta(strConsulta);
            grdUsuarios.DataBind();
        }

        private void LlenadoInicial() {
            for (int i = 1; i <= 12; i++)
            {
                cmbMes.Items.Add(i.ToString());
            }
            cmbGenero1.Items.Add("Masculino");
            cmbGenero1.Items.Add("Femenino");

            ListItem lstItem = new ListItem();
            DataTable dtAgencias = con.EjecutarConsulta("SELECT ID_SEDE, NOMBRE FROM SEDE");
            for (int i = 0; i < dtAgencias.Rows.Count; i++)
            {
                lstItem = new ListItem();
                lstItem.Value = dtAgencias.Rows[i]["ID_SEDE"].ToString();
                lstItem.Text = dtAgencias.Rows[i]["NOMBRE"].ToString();
                cmbAgencia.Items.Add(lstItem);
            }

            DataTable dtRoles = con.EjecutarConsulta("SELECT * FROM ROL");
            for (int i = 0; i < dtRoles.Rows.Count; i++)
            {
                lstItem = new ListItem();
                lstItem.Value = dtRoles.Rows[i]["ID_ROL"].ToString();
                lstItem.Text = dtRoles.Rows[i]["DESCRIPCION"].ToString();
                cmbRol.Items.Add(lstItem);
            }
        }

        protected void grdUsuarios_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdUsuarios.PageIndex = e.NewPageIndex;
            grdUsuarios.DataBind();
        }

        protected void grdUsuarios_SelectedIndexChanged(object sender, EventArgs e)
        {
            //SE LLENA EL DETALLE DE USUARIOS
            Usuario userDet = new Usuario(con, int.Parse(grdUsuarios.Rows[grdUsuarios.SelectedIndex].Cells[1].Text.ToString()));

            txtIdUsuario.Text = userDet.Id_Usuario.ToString();
            txtUsuario.Text = userDet.Username.ToString();
            txtNombres.Text = userDet.Nombres.ToString();
            txtApellidos.Text = userDet.Apellidos.ToString();
            txtIdentificacion.Text = userDet.Identificacion.ToString();
            if (userDet.Genero.ToString().Equals("M")) {
                txtGenero.Text = "Masculino";
            } else {
                if (userDet.Genero.ToString().Equals("F"))
                {
                    txtGenero.Text = "Femenino";
                }
                else {
                    txtGenero.Text = "Sin Definir";
                }
            }
            txtFechaNac.Text = userDet.Fecha_Nacimiento.ToString("MMM-dd-yyyy").ToUpper();
            txtAgencia.Text = userDet.Nombre_Agencia.ToString();
            txtRol.Text = userDet.Rol_Descripcion.ToString();
            txtDia.Text = userDet.Fecha_Nacimiento.Day.ToString();
            cmbMes.SelectedIndex = userDet.Fecha_Nacimiento.Month -1;
            txtAno.Text = userDet.Fecha_Nacimiento.Year.ToString();
        }

        protected void txtBusquedaU_TextChanged(object sender, EventArgs e)
        {
            
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            if (grdUsuarios.SelectedIndex >= 0) {
                pnlConfElim.Visible = true;
            } else {
                Alerta("¡Seleccione un usuario para eliminar!", 1);
            }

        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            Busqueda();
        }

        private void Busqueda() {
            LlenarGrid("select ID_USUARIO AS ID, username as USUARIO, nombres as NOMBRES, apellidos AS APELLIDOS from usuario where username like '%" + txtBusqueda.Text.ToString() + "%' OR nombres like '%" + txtBusqueda.Text.ToString() + "%' or apellidos like '%" + txtBusqueda.Text.ToString() + "%'");
            if (grdUsuarios.Rows.Count == 0)
            {
                pnlAlertaNoResultados.Visible = true;
            }
        }

        private void LimpiarCampos() {
            txtIdUsuario.Text = "";
            txtUsuario.Text = "";
            txtNombres.Text = "";
            txtApellidos.Text = "";
            txtIdentificacion.Text = "";
            txtGenero.Text = "";
            txtFechaNac.Text = "";
            txtAgencia.Text = "";
            txtRol.Text = "";
        }

        protected void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            CambiarModoPnlDetalle(false);
        }

        

        private void CambiarModoPnlDetalle(bool blnDetalle) {
            if (blnDetalle == true) {
                cmbAgencia.Visible = false;
                cmbGenero1.Visible = false;
                txtAgencia.Visible = true;
                txtGenero.Visible = true;
                btnCancelar.Visible = false;
                btnGuardar.Visible = false;
                txtRol.Visible = true;
                cmbRol.Visible = false;

                txtIdUsuario.Enabled = false;
                txtUsuario.Enabled = false;
                txtNombres.Enabled = false;
                txtApellidos.Enabled = false;
                txtIdentificacion.Enabled = false;
                txtGenero.Enabled = false;
                txtFechaNac.Enabled = false;
                txtAgencia.Enabled = false;
                txtRol.Enabled = false;

                txtDia.Visible = false;
                cmbMes.Visible = false;
                txtAno.Visible = false;
                txtFechaNac.Visible = true;

            } else {
                cmbAgencia.Visible = true;
                cmbGenero1.Visible = true;
                txtAgencia.Visible = false;
                txtGenero.Visible = false;
                txtFechaNac.Visible = false;
                btnCancelar.Visible = true;
                btnGuardar.Visible = true;
                txtRol.Visible = false;
                cmbRol.Visible = true;

                txtDia.Visible = true;
                cmbMes.Visible = true;
                txtAno.Visible = true;

                txtUsuario.Enabled = true;
                txtNombres.Enabled = true;
                txtApellidos.Enabled = true;
                txtIdentificacion.Enabled = true;
            }  
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            CambiarModoPnlDetalle(true);
        }

        protected void btnConfElim_Click(object sender, EventArgs e)
        {

            if (con.EjecutarComando("DELETE FROM USUARIO WHERE ID_USUARIO=" + txtIdUsuario.Text.ToString()) == true) {
                Busqueda();
                Alerta("Usuario eliminado correctamente.", 2);

                //BITACORA
                try {con.RegistrarBitacora((Usuario)Session["USUARIO"], "ELIMINAR", "USUARIO "+ txtUsuario.Text);} catch (Exception) { }
                
            }
            else
            {
                Alerta("Ocurrió un error eliminando, refresque la pagina e intente de nuevo.", 1);
            }
        }

        private void Alerta(string textoAlerta, int tipoAlerta) {
            if (tipoAlerta == 1) {
                //danger
                pnlAlerta.CssClass = "col-md-12 alert alert-danger";
            } else {
                
                if (tipoAlerta == 2) {
                    //info
                    pnlAlerta.CssClass = "col-md-12 alert alert-info";
                } else {
                    //success
                    pnlAlerta.CssClass = "col-md-12 alert alert-success";
                }
            }
            lblAlerta.Text = textoAlerta;
            pnlAlerta.Visible = true;
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            string strGenero, strComandoSQL, strAlerta;

            if (CamposMandatorios() == true)
            {
                if (cmbGenero1.SelectedValue.ToString().Equals("Masculino")) { strGenero = "M"; } else { strGenero = "F"; }

                DateTime dtFecha = new DateTime(int.Parse(txtAno.Text), int.Parse(cmbMes.SelectedValue.ToString()), int.Parse(txtDia.Text));

                if (txtIdUsuario.Text.Length > 0) {
                    strComandoSQL = "UPDATE USUARIO SET username='" + txtUsuario.Text.ToString() + "', Nombres='" + txtNombres.Text.ToString() + "', Apellidos='" + txtApellidos.Text.ToString() + "',Identificacion='" + txtIdentificacion.Text.ToString() + "',Genero='" + strGenero + "',Fecha_Nacimiento='" + dtFecha.ToShortDateString() + "',ID_SEDE=" + cmbAgencia.SelectedValue.ToString() + ",Id_Rol=" + cmbRol.SelectedValue.ToString() + " WHERE Id_Usuario="+ txtIdUsuario.Text.ToString();
                    strAlerta = "Usuario modificado exitosamente!";
                    //BITACORA
                    try { con.RegistrarBitacora((Usuario)Session["USUARIO"], "ACTUALIZAR", "USUARIO " + txtUsuario.Text); } catch (Exception) { }
                } else {
                    strComandoSQL = "INSERT INTO USUARIO (username,Nombres,Apellidos,Identificacion,Genero,Fecha_Nacimiento,ID_SEDE,Id_Rol) VALUES('" + txtUsuario.Text.ToString() + "','" + txtNombres.Text.ToString() + "','" + txtApellidos.Text.ToString() + "','" + txtIdentificacion.Text.ToString() + "','" + strGenero + "','" + dtFecha.ToShortDateString() + "'," + cmbAgencia.SelectedValue.ToString() + "," + cmbRol.SelectedValue.ToString() + ")";
                    strAlerta = "Usuario agregado exitosamente!";
                    //BITACORA
                    try { con.RegistrarBitacora((Usuario)Session["USUARIO"], "CREAR", "USUARIO " + txtUsuario.Text); } catch (Exception) { }
                }

                if (con.EjecutarComando(strComandoSQL) == true)
                {
                    Alerta(strAlerta, 3);
                    CambiarModoPnlDetalle(true);
                    LimpiarCampos();
                    Busqueda();
                }
                else { Alerta("Ocurrio un error, refresque la pagina e intente de nuevo!", 1); }

            }
            else
            {
                Alerta("Ingrese los campos mandatorios marcados en rojo!", 1);
            }
        }

        private bool CamposMandatorios() {
            bool todoLleno = true;
            //usuario
            if (txtUsuario.Text.Length > 0) { } else {
                lblUsuario.ForeColor = Color.Red;
                todoLleno = false;
            }

            //nombres
            if (txtNombres.Text.Length > 0) { }
            else
            {
                lblNombres.ForeColor = Color.Red;
                todoLleno = false;
            }

            //apellidos
            if (txtApellidos.Text.Length > 0) { }
            else
            {
                lblApellidos.ForeColor = Color.Red;
                todoLleno = false;
            }

            //Identificacion
            if (txtIdentificacion.Text.Length > 0) { }
            else
            {
                lblIdentificacion.ForeColor = Color.Red;
                todoLleno = false;
            }

            //Genero
            if (cmbGenero1.Text.Length > 0) { }
            else
            {
                lblGenero.ForeColor = Color.Red;
                todoLleno = false;
            }
            //Fecha nacimiento
            if (txtDia.Text.Length > 0 & cmbMes.SelectedValue.Length > 0 & txtAno.Text.Length > 0) {
                    
            } else {
                lblFechaNac.ForeColor = Color.Red;
                todoLleno = false;
            }


            //Agencia
            if (cmbAgencia.Text.Length > 0) { }
            else
            {
                lblAgencia.ForeColor = Color.Red;
                todoLleno = false;
            }
            //Rol
            if (cmbRol.Text.Length > 0) { }
            else
            {
                lblRol.ForeColor = Color.Red;
                todoLleno = false;
            }
            return todoLleno;
        }

        protected void calFechaNac_SelectionChanged(object sender, EventArgs e)
        {
            //txtFechaNac.Text = calFechaNac.SelectedDate.ToString();
        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            if (grdUsuarios.SelectedIndex >= 0)
            {
                CambiarModoPnlDetalle(false);
            }
            else {
                Alerta("¡Seleccione un usuario para modificar!", 1);
            }
            
        }

        protected void btnReinicioClave_Click(object sender, EventArgs e)
        {
            if (txtIdUsuario.Text.Length > 0) {
                con.EjecutarComando("UPDATE USUARIO SET PASSWORD='' WHERE ID_USUARIO="+txtIdUsuario.Text);
                Alerta("Contraseña reiniciada correctamente.", 3);
                //BITACORA
                try { con.RegistrarBitacora((Usuario)Session["USUARIO"], "ACTUALIZAR", "CONTRASEÑA USUARIO " + txtUsuario.Text); } catch (Exception) { }
            }
        }
    }
}