﻿using APPARMSA.Clases;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace APPARMSA
{
    public partial class Permisos : Page
    {
        Conexion con = new Conexion();
        bool crearPermisos;
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidacionPermisosRol();
            Busqueda();
            OcultarPanelesAlerta();
            if (!this.IsPostBack) {
                CambiarModoPnlDetalle(true);
                LlenadoInicial();
            }
        }

        private void ValidacionPermisosRol() {
            //Valida si hay inicio de sesion
            if (Session["USUARIO"] != null)
            {
                try
                {
                    Usuario loggedUser = (Usuario)Session["USUARIO"];
                    foreach (DataRow dr in loggedUser.Permisos.Rows)
                    {
                        //PERMISOS A LA PAGINA COMO TAL
                        if (int.Parse(dr["ID_PERMISO"].ToString()) == 7)
                        {
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                //Si tiene permisos para esta pagina

                            }
                            else
                            {
                                Response.Redirect("Inicio.aspx");
                            }
                        }
                        else { }
                    }
                }
                catch (Exception)
                {
                    //Ya que dio un error se cierra la sesión
                    Session["USUARIO"] = null;
                    Response.Redirect("AppLogin.aspx");
                }
            }
            else
            {
                Response.Redirect("AppLogin.aspx");
            }
        }

        private void OcultarPanelesAlerta() {
            pnlAlerta.Visible = false;
            pnlAlertaNoResultados.Visible = false;
            pnlConfElim.Visible = false;
        }
        
        private void LlenarGrid(String strConsulta) {
            grdRoles.DataSource = con.EjecutarConsulta(strConsulta);
            grdRoles.DataBind();
        }

        private void LlenadoInicial() {
            

        }

        protected void grdRoles_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdRoles.PageIndex = e.NewPageIndex;
            grdRoles.DataBind();
        }

        protected void grdRoles_SelectedIndexChanged(object sender, EventArgs e)
        {

            pnlMdlViajes.Visible = true;
            CambiarModoPnlDetalle(true);

            Rol rol = new Rol(con, int.Parse(grdRoles.Rows[grdRoles.SelectedIndex].Cells[1].Text.ToString()));

            txtIdRol.Text = rol.IdRol.ToString();
            txtRol.Text = rol.Descripcion.ToString();
            crearPermisos = false;
            //se recorren los permisos para marcar los checkbox
            if (rol.Permisos.Rows.Count > 0) {
                foreach (DataRow dr in rol.Permisos.Rows) {
                    switch (int.Parse(dr["ID_PERMISO"].ToString())) {
                        case 1:
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                ckbBodega.Checked = true;
                            }
                            else {
                                ckbBodega.Checked = false;
                            }
                            break;
                        case 2:
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                ckbCaja.Checked = true;
                            }
                            else
                            {
                                ckbCaja.Checked = false;
                            }
                            break;
                        case 3:
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                ckbUsuario.Checked = true;
                            }
                            else
                            {
                                ckbUsuario.Checked = false;
                            }
                            break;
                        case 4:
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                ckbCita.Checked = true;
                            }
                            else
                            {
                                ckbCita.Checked = false;
                            }
                            break;
                        case 5:
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                ckbExpediente.Checked = true;
                            }
                            else
                            {
                                ckbExpediente.Checked = false;
                            }
                            break;
                        case 6:
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                ckbFarmacia.Checked = true;
                            }
                            else
                            {
                                ckbFarmacia.Checked = false;
                            }
                            break;
                        case 7:
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                ckbRoles.Checked = true;
                            }
                            else
                            {
                                ckbRoles.Checked = false;
                            }
                            break;
                        case 8:
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                ckbProveedor.Checked = true;
                            }
                            else
                            {
                                ckbProveedor.Checked = false;
                            }
                            break;
                        case 9:
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                ckbFacturacion.Checked = true;
                            }
                            else
                            {
                                ckbFacturacion.Checked = false;
                            }
                            break;
                        case 10:
                            if (dr["HABILITADO"].ToString().Equals("True"))
                            {
                                ckbOdonto.Checked = true;
                            }
                            else
                            {
                                ckbOdonto.Checked = false;
                            }
                            break;
                        default:
                            break;
                    }
                }
            } else {
                //Si no tiene nada es porque es nuevo
                crearPermisos = true;

                ckbBodega.Checked = false;
                ckbCaja.Checked = false;
                ckbUsuario.Checked = false;
                ckbCita.Checked = false;
                ckbExpediente.Checked = false;
                ckbFarmacia.Checked = false;
                ckbRoles.Checked = false;
                ckbProveedor.Checked = false;
                ckbFacturacion.Checked = false;
                ckbOdonto.Checked = false;

            }


        }

        protected void txtBusquedaU_TextChanged(object sender, EventArgs e)
        {
            
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            if (grdRoles.SelectedIndex >= 0) {
                pnlConfElim.Visible = true;
            } else {
                Alerta("¡Seleccione un tipo de usuario para eliminar!", 1);
            }

        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            Busqueda();
        }

        private void Busqueda() {
            LlenarGrid("SELECT ID_ROL AS ID, DESCRIPCION FROM ROL WHERE DESCRIPCION LIKE '%" + txtBusqueda.Text.ToString() + "%'");
            if (grdRoles.Rows.Count == 0)
            {
                pnlAlertaNoResultados.Visible = true;
            }
        }

        private void LimpiarCampos() {
            txtIdRol.Text = "";
            txtRol.Text = "";
        }

        protected void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            CambiarModoPnlDetalle(false);
            pnlMdlViajes.Visible = false;
        }

        

        private void CambiarModoPnlDetalle(bool blnDetalle) {
            txtIdRol.Enabled = false;

            if (blnDetalle) {
                txtRol.Enabled = false;

                ckbBodega.Enabled = false;
                ckbCaja.Enabled = false;
                ckbUsuario.Enabled = false;
                ckbCita.Enabled = false;
                ckbExpediente.Enabled = false;
                ckbFarmacia.Enabled = false;
                ckbRoles.Enabled = false;
                ckbProveedor.Enabled = false;
                ckbFacturacion.Enabled = false;
                ckbOdonto.Enabled = false;


                //Botones
                btnGuardar.Visible = false;
                btnCancelar.Visible = false;

                
            } else {
                txtRol.Enabled = true;

                ckbBodega.Enabled = true;
                ckbCaja.Enabled = true;
                ckbUsuario.Enabled = true;
                ckbCita.Enabled = true;
                ckbExpediente.Enabled = true;
                ckbFarmacia.Enabled = true;
                ckbRoles.Enabled = true;
                ckbProveedor.Enabled = true;
                ckbFacturacion.Enabled = true;
                ckbOdonto.Enabled = false;

                //Botones
                btnGuardar.Visible = true;
                btnCancelar.Visible = true;
            }

        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            CambiarModoPnlDetalle(true);
        }

        protected void btnConfElim_Click(object sender, EventArgs e)
        {
            DataTable dtValidacion = con.EjecutarConsulta("SELECT ID_USUARIO AS ID FROM USUARIO WHERE ID_ROL=" + txtIdRol.Text.ToString());
            if (dtValidacion.Rows.Count > 0) {
                Alerta("No puede eliminar este tipo de usuario porque tiene usuarios asignados.", 1);
            } else {
                //SE eliminan los permisos asignados a este rol
                if (con.EjecutarComando("DELETE FROM PERMISO_X_ROL WHERE ID_ROL=" + txtIdRol.Text.ToString()) == true)
                {
                    //Se elimina el rol
                    if (con.EjecutarComando("DELETE FROM ROL WHERE ID_ROL=" + txtIdRol.Text.ToString()) == true) {
                        Busqueda();
                        Alerta("Tipo de usuario eliminado correctamente.", 2);

                        //BITACORA
                        try { con.RegistrarBitacora((Usuario)Session["USUARIO"], "ELIMINAR", "TIPO DE USUARIO " + txtRol.Text); } catch (Exception) { }
                    } else {
                        Alerta("Ocurrio un error eliminando, refresque la pagina e intente de nuevo.", 1);
                    }
                }
                else
                {
                    Alerta("Ocurrio un error eliminando, refresque la pagina e intente de nuevo.", 1);
                }
            }


            
        }

        private void Alerta(string textoAlerta, int tipoAlerta) {
            if (tipoAlerta == 1) {
                //danger
                pnlAlerta.CssClass = "col-md-12 alert alert-danger";
            } else {
                
                if (tipoAlerta == 2) {
                    //info
                    pnlAlerta.CssClass = "col-md-12 alert alert-info";
                } else {
                    //success
                    pnlAlerta.CssClass = "col-md-12 alert alert-success";
                }
            }
            lblAlerta.Text = textoAlerta;
            pnlAlerta.Visible = true;
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            
            string strComandoSQL, strAlerta;
            

            if (CamposMandatorios() == true)
            {
                if (txtIdRol.Text.Length > 0) {
                    strComandoSQL = "UPDATE ROL SET DESCRIPCION='" + txtRol.Text.ToString() + "' WHERE ID_ROL=" + txtIdRol.Text.ToString();

                    Rol rol = new Rol(con, int.Parse(txtIdRol.Text.ToString()));

                    if (rol.Permisos.Rows.Count > 0)
                    {
                        crearPermisos = false;
                    }
                    else
                    {
                        crearPermisos = true;
                    }

                    //Se guardan los permisos del rol
                    int iHabilitado;

                    for (int i = 1; i <= 18; i++) {
                        iHabilitado = 0;
                        switch (i) {
                            case 1:
                                if (ckbBodega.Checked) { iHabilitado = 1; } else { iHabilitado = 0; }
                                break;
                            case 2:
                                if (ckbCaja.Checked) { iHabilitado = 1; } else { iHabilitado = 0; }
                                break;
                            case 3:
                                if (ckbUsuario.Checked) { iHabilitado = 1; } else { iHabilitado = 0; }
                                break;
                            case 4:
                                if (ckbCita.Checked) { iHabilitado = 1; } else { iHabilitado = 0; }
                                break;
                            case 5:
                                if (ckbExpediente.Checked) { iHabilitado = 1; } else { iHabilitado = 0; }
                                break;
                            case 6:
                                if (ckbFarmacia.Checked) { iHabilitado = 1; } else { iHabilitado = 0; }
                                break;
                            case 7:
                                if (ckbRoles.Checked) { iHabilitado = 1; } else { iHabilitado = 0; }
                                break;
                            case 8:
                                if (ckbProveedor.Checked) { iHabilitado = 1; } else { iHabilitado = 0; }
                                break;
                            case 9:
                                if (ckbFacturacion.Checked) { iHabilitado = 1; } else { iHabilitado = 0; }
                                break;
                            case 10:
                                if (ckbOdonto.Checked) { iHabilitado = 1; } else { iHabilitado = 0; }
                                break;    
                            default:
                                iHabilitado = 0;
                                break;
                        }

                        if (crearPermisos) {
                            if (con.EjecutarComando("INSERT INTO PERMISO_X_ROL (ID_ROL, ID_PERMISO,HABILITADO,DESCRIPCION) VALUES(" + txtIdRol.Text.ToString() +","+ i.ToString() +","+ iHabilitado.ToString() +",'')") == true) { } else { }
                        } else {
                            if (con.EjecutarComando("UPDATE PERMISO_X_ROL SET HABILITADO="+ iHabilitado.ToString() + " WHERE ID_ROL=" + txtIdRol.Text.ToString() + " AND ID_PERMISO=" + i.ToString()) == true) { } else { }
                        }

                    }


                    if (crearPermisos) { } else { }

                    strAlerta = "Tipo de usuario modificado exitosamente!";
                    //BITACORA
                    try { con.RegistrarBitacora((Usuario)Session["USUARIO"], "MODIFICAR", "TIPO DE USUARIO " + txtRol.Text); } catch (Exception) { }

                } else {
                    strComandoSQL = "INSERT INTO ROL(DESCRIPCION) VALUES('" + txtRol.Text.ToString() + "')";
                    strAlerta = "Tipo de usuario agregado exitosamente!";
                    //BITACORA
                    try { con.RegistrarBitacora((Usuario)Session["USUARIO"], "CREAR", "TIPO DE USUARIO " + txtRol.Text); } catch (Exception) { }
                }

                if (con.EjecutarComando(strComandoSQL) == true)
                {
                    Alerta(strAlerta, 3);
                    CambiarModoPnlDetalle(true);
                    LimpiarCampos();
                    Busqueda();
                }
                else { Alerta("Ocurrio un error, refresque la pagina e intente de nuevo!", 1); }
                
            }
            else
            {
                Alerta("Ingrese los campos mandatorios marcados en rojo!", 1);
            }
        }

        private bool CamposMandatorios() {
            bool todoLleno = true;

            //nombres
            if (txtRol.Text.Length > 0) { }
            else
            {
                lblRol.ForeColor = Color.Red;
                todoLleno = false;
            }
            
            return todoLleno;
        }

        protected void calFechaNac_SelectionChanged(object sender, EventArgs e)
        {
            //txtFechaNac.Text = calFechaNac.SelectedDate.ToString();
        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            if (grdRoles.SelectedIndex >= 0)
            {
                pnlMdlViajes.Visible = true;
                CambiarModoPnlDetalle(false);
            }
            else {
                Alerta("¡Seleccione un tipo de usuario para modificar!", 1);
            }
            
        }
    }
}