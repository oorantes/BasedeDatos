﻿using APPARMSA.Clases;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace APPARMSA
{
    public partial class SiteMaster : MasterPage
    {
        Conexion con = new Conexion();
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidacionPermisosRol();
        }

        private void ValidacionPermisosRol() {
            menu_Bodega.Visible = false;
            menu_Caja.Visible = false;
            menu_Usuarios.Visible = false;
            menu_Citas.Visible = false;
            menu_Expedientes.Visible = false;
            menu_Facturacion.Visible = false;
            menu_Farmacia.Visible = false;
            menu_Roles.Visible = false;
            menu_Proveedores.Visible = false;
            menu_Odonto.Visible = false;

            if (Session["USUARIO"] != null) {
                try {
                    Usuario user = (Usuario)Session["USUARIO"];

                    if (user.Permisos.Rows.Count > 0)
                    {
                        foreach (DataRow dr in user.Permisos.Rows) {

                            //Modulo Viajes
                            if (int.Parse(dr["ID_PERMISO"].ToString()) == 1) {
                                if (dr["HABILITADO"].ToString().Equals("True")) {
                                    menu_Bodega.Visible = true;
                                } else {
                                    menu_Bodega.Visible = false;
                                }   
                            }
                            //Modulo Catalogos
                            if (int.Parse(dr["ID_PERMISO"].ToString()) == 2)
                            {
                                if (dr["HABILITADO"].ToString().Equals("True"))
                                {
                                    menu_Caja.Visible = true;
                                }
                                else
                                {
                                    menu_Caja.Visible = false;
                                }
                            }
                            //Modulo Ventas
                            if (int.Parse(dr["ID_PERMISO"].ToString()) == 3)
                            {
                                if (dr["HABILITADO"].ToString().Equals("True"))
                                {
                                    menu_Usuarios.Visible = true;
                                }
                                else
                                {
                                    menu_Usuarios.Visible = false;
                                }
                            }
                            if (int.Parse(dr["ID_PERMISO"].ToString()) == 4)
                            {
                                if (dr["HABILITADO"].ToString().Equals("True"))
                                {
                                    menu_Citas.Visible = true;
                                }
                                else
                                {
                                    menu_Citas.Visible = false;
                                }
                            }
                            if (int.Parse(dr["ID_PERMISO"].ToString()) == 5)
                            {
                                if (dr["HABILITADO"].ToString().Equals("True"))
                                {
                                    menu_Expedientes.Visible = true;
                                }
                                else
                                {
                                    menu_Expedientes.Visible = false;
                                }
                            }
                            if (int.Parse(dr["ID_PERMISO"].ToString()) == 6)
                            {
                                if (dr["HABILITADO"].ToString().Equals("True"))
                                {
                                    menu_Farmacia.Visible = true;
                                }
                                else
                                {
                                    menu_Farmacia.Visible = false;
                                }
                            }
                            if (int.Parse(dr["ID_PERMISO"].ToString()) == 7)
                            {
                                if (dr["HABILITADO"].ToString().Equals("True"))
                                {
                                    menu_Roles.Visible = true;
                                }
                                else
                                {
                                    menu_Roles.Visible = false;
                                }
                            }
                            if (int.Parse(dr["ID_PERMISO"].ToString()) == 8)
                            {
                                if (dr["HABILITADO"].ToString().Equals("True"))
                                {
                                    menu_Proveedores.Visible = true;
                                }
                                else
                                {
                                    menu_Proveedores.Visible = false;
                                }
                            }
                            if (int.Parse(dr["ID_PERMISO"].ToString()) == 9)
                            {
                                if (dr["HABILITADO"].ToString().Equals("True"))
                                {
                                    menu_Facturacion.Visible = true;
                                }
                                else
                                {
                                    menu_Facturacion.Visible = false;
                                }
                            }
                            if (int.Parse(dr["ID_PERMISO"].ToString()) == 10)
                            {
                                if (dr["HABILITADO"].ToString().Equals("True"))
                                {
                                    menu_Odonto.Visible = true;
                                }
                                else
                                {
                                    menu_Odonto.Visible = false;
                                }
                            }
                        }
                    }
                    else {

                        menu_Bodega.Visible = false;
                        menu_Caja.Visible = false;
                        menu_Usuarios.Visible = false;
                        menu_Citas.Visible = false;
                        menu_Expedientes.Visible = false;
                        menu_Facturacion.Visible = false;
                        menu_Farmacia.Visible = false;
                        menu_Roles.Visible = false;
                        menu_Proveedores.Visible = false;
                        menu_Odonto.Visible = false;
                    }

                } catch (Exception)
                {
                    //Si no se logro convertir es incorrecto, se coloca null para que la pagina redireccione a login
                    Session["USUARIO"] = null;
                }
            } else
            {
                //Si es null cada pagina se encargara de redireccionar a la de login
                Response.Redirect("AppLogin.aspx");
            }
        }

        protected void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            Session["USUARIO"] = null;
            Response.Redirect("AppLogin.aspx");
        }
    }
}